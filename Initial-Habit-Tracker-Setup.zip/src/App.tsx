import React from 'react';
import { Layout } from './components/Layout';
import { HabitCard } from './components/HabitCard';
import { Plus } from 'lucide-react';
import type { Habit } from './types';

// Temporary mock data
const mockHabits: Habit[] = [
  {
    id: '1',
    title: 'Morning Exercise',
    description: '30 minutes of cardio or strength training',
    frequency: 'daily',
    status: 'active',
    progress: 75,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'Read Books',
    description: 'Read at least 20 pages',
    frequency: 'daily',
    status: 'completed',
    progress: 100,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '3',
    title: 'Meditation',
    description: '15 minutes of mindfulness meditation',
    frequency: 'daily',
    status: 'active',
    progress: 30,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

function App() {
  return (
    <Layout>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Your Habits</h1>
            <p className="text-gray-500">Track and manage your daily habits</p>
          </div>
          <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Plus className="w-5 h-5 mr-2" />
            Add Habit
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockHabits.map((habit) => (
            <HabitCard key={habit.id} habit={habit} />
          ))}
        </div>
      </div>
    </Layout>
  );
}

export default App;