import React from 'react';
import { MoreVertical, CheckCircle2 } from 'lucide-react';
import type { Habit } from '../types';

interface HabitCardProps {
  habit: Habit;
}

export function HabitCard({ habit }: HabitCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          <div className="flex-shrink-0">
            <CheckCircle2 className={`w-6 h-6 ${habit.status === 'completed' ? 'text-green-500' : 'text-gray-400'}`} />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-900">{habit.title}</h3>
            <p className="text-sm text-gray-500">{habit.description}</p>
          </div>
        </div>
        <button className="p-1 rounded-lg hover:bg-gray-100">
          <MoreVertical className="w-4 h-4 text-gray-400" />
        </button>
      </div>
      
      <div className="mt-4">
        <div className="flex justify-between text-xs text-gray-500 mb-1">
          <span>Progress</span>
          <span>{habit.progress}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full" 
            style={{ width: `${habit.progress}%` }}
          />
        </div>
      </div>
      
      <div className="mt-4 flex items-center justify-between text-xs text-gray-500">
        <span>Frequency: {habit.frequency}</span>
        <span>Updated {new Date(habit.updatedAt).toLocaleDateString()}</span>
      </div>
    </div>
  );
}