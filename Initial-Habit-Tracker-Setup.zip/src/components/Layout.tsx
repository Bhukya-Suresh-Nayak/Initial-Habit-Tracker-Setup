import React from 'react';
import { Menu, User, BarChart2, Settings, LogOut } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
        <div className="flex items-center justify-between p-4 border-b">
          <h1 className="text-xl font-bold text-gray-900">Habit Tracker</h1>
          <button className="p-2 rounded-lg hover:bg-gray-100">
            <Menu className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        <nav className="p-4 space-y-2">
          <a href="#" className="flex items-center px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <BarChart2 className="w-5 h-5 mr-3" />
            Dashboard
          </a>
          <a href="#" className="flex items-center px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <User className="w-5 h-5 mr-3" />
            Profile
          </a>
          <a href="#" className="flex items-center px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <Settings className="w-5 h-5 mr-3" />
            Settings
          </a>
          <a href="#" className="flex items-center px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-100">
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </a>
        </nav>
      </aside>

      {/* Main content */}
      <main className="ml-64 p-8">
        {children}
      </main>
    </div>
  );
}